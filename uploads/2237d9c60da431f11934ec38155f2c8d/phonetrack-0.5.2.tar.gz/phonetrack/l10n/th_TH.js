OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "ติดตามสถานที่",
    "PhoneTrack proximity alert (%s and %s)" : "ติดตามใกล้ชิดเตือน (%s และ %s)",
    "Device \"%s\" is now farther than %sm from \"%s\"." : "Device \"%s\" is now farther than %sm from \"%s\".",
    "left" : "ซ้าย",
    "right" : "ขวา",
    "daily" : "ทุกวัน",
    "weekly" : "รายสัปดาห์"
},
"nplurals=1; plural=0;");
