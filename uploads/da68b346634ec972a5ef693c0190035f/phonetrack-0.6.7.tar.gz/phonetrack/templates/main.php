<?php
script('phonetrack', 'phonetrack');

// fontawesome/fortawesome
style('phonetrack', 'fontawesome-free/css/all.min');
style('phonetrack', 'style');
style('phonetrack', 'phonetrack');

?>

<div id="app">
	<div id="app-content">
			<?php print_unescaped($this->inc('maincontent')); ?>
	</div>
</div>
