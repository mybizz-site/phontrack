OC.L10N.register(
    "phonetrack",
    {
    "never" : "nikoli",
    "daily" : "dnevno",
    "weekly" : "tedensko"
},
"nplurals=4; plural=(n%100==1 ? 1 : n%100==2 ? 2 : n%100==3 || n%100==4 ? 3 : 0);\nX-Generator: crowdin.com\nX-Crowdin-Project: phonetrack\nX-Crowdin-Language: sl");
