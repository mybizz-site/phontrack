OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "PhoneTrack",
    "Show lines" : "Näytä rivit"
},
"nplurals=2; plural=(n != 1);");
