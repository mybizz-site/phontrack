OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "PhoneTrack"
},
"nplurals=2; plural=(n != 1);");
