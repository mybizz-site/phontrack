OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "PhoneTrack",
    "left" : "vasen",
    "right" : "oikea",
    "Show lines" : "Näytä rivit"
},
"nplurals=2; plural=(n != 1);");
