OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "PhoneTrack",
    "left" : "esquerra",
    "right" : "dreta",
    "Show lines" : "Mostra les línies",
    "Hide lines" : "Amaga línies",
    "Activate automatic zoom" : "Activar zoom automàtic",
    "Disable automatic zoom" : "Deshabilita zoom automàtic",
    "Show last point tooltip" : "Mostra el misatge del darrer punt",
    "Hide last point tooltip" : "Amaga el misatge del darrer punt",
    "Zoom on all devices" : "Zoom de tots els dispositius",
    "Click on the map to move the point, press ESC to cancel" : "Feu clic al mapa per desplaçar el punt, premeu ESC per anul·lar"
},
"nplurals=2; plural=(n != 1);");
