module.exports = {
	globals: {
		appVersion: true
	},
	extends: [
		'@nextcloud'
	]
}
