OC.L10N.register(
    "phonetrack",
    {
    "Show lines" : "Vis linjer",
    "Hide lines" : "Skjule linjer",
    "Zoom on all devices" : "Zoom på alle enheder",
    "Files are created in '{exdir}'" : "Filer bliver oprettet i '{exdir}'",
    "Automatic purge is triggered daily and will delete points older than selected duration" : "Automatisk oprydning bliver aktiveret dagligt og vil slette punkter ældre end den valgte varighed",
    "user name" : "brugernavn",
    "Distance" : "Afstand"
},
"nplurals=2; plural=(n != 1);");
