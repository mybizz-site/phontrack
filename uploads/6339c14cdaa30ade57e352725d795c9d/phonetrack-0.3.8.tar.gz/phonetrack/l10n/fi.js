OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "PhoneTrack",
    "left" : "vasen",
    "right" : "oikea",
    "Show lines" : "Näytä rivit"
},
"nplurals=2; plural=(n != 1);\nX-Generator: crowdin.com\nX-Crowdin-Project: phonetrack\nX-Crowdin-Language: fi");
