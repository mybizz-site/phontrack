OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "PhoneTrack",
    "Quota was successfully saved" : "Quota was successfully saved"
},
"nplurals=2; plural=(n != 1);");
