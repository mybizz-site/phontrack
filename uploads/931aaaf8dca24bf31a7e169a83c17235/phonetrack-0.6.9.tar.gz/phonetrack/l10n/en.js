OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack device {device} of session {session} has entered geofence {geofence}" : "PhoneTrack device {device} of session {session} has entered geofence {geofence}",
    "PhoneTrack" : "PhoneTrack",
    "Quota was successfully saved" : "Quota was successfully saved"
},
"nplurals=2; plural=(n != 1);");
