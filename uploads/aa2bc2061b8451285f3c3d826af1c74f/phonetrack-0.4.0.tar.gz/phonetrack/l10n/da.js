OC.L10N.register(
    "phonetrack",
    {
    "Show lines" : "Vis linjer",
    "Hide lines" : "Skjule linjer",
    "Zoom on all devices" : "Zoom på alle enheder"
},
"nplurals=2; plural=(n != 1);\nX-Generator: crowdin.com\nX-Crowdin-Project: phonetrack\nX-Crowdin-Language: da");
