OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "PhoneTrack"
},
"nplurals=2; plural=(n != 1);\nX-Generator: crowdin.com\nX-Crowdin-Project: phonetrack\nX-Crowdin-Language: en-GB");
