OC.L10N.register(
    "phonetrack",
    {
    "PhoneTrack" : "ติดตามสถานที่Bitzaron",
    "left" : "ซ้าย",
    "right" : "ขวา",
    "daily" : "ทุกวัน",
    "weekly" : "รายสัปดาห์"
},
"nplurals=1; plural=0;\nX-Generator: crowdin.com\nX-Crowdin-Project: phonetrack\nX-Crowdin-Language: th");
